// Minimal front-end behavior: product injection, cart, contact form behavior.
const products = [
  {id: 'cj1', name: 'Gangsta Cold Brew - 12oz', price: 6.00, desc: 'Concentrated cold brew with bold notes.'},
  {id: 'ej1', name: 'Moon Elixir - 2oz', price: 12.00, desc: 'Botanical energy shot. Legal stimulation.'},
  {id: 'merch1', name: 'Gangsta Tee', price: 28.00, desc: 'Soft cotton, street fit.'},
  {id: 'merch2', name: 'Sticker Pack', price: 5.00, desc: 'Four high-quality vinyl stickers.'}
];

function $(s){return document.querySelector(s)}
function $all(s){return document.querySelectorAll(s)}

const productsGrid = $('#productsGrid');
const cartBtn = $('#cartBtn');
const cartModal = $('#cartModal');
const closeCart = $('#closeCart');
const cartItemsDiv = $('#cartItems');
const cartCount = $('#cartCount');
const cartTotal = $('#cartTotal');
const checkoutBtn = $('#checkoutBtn');

// render products
products.forEach(p=>{
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `
    <div class="product-img">IMAGE</div>
    <div class="product-meta">
      <div>
        <div style="font-weight:700">${p.name}</div>
        <div class="muted" style="font-size:.9rem">${p.desc}</div>
      </div>
      <div style="text-align:right">
        <div class="price">$${p.price.toFixed(2)}</div>
        <button class="btn add" data-id="${p.id}" style="margin-top:.4rem">Add</button>
      </div>
    </div>`;
  productsGrid.appendChild(card);
});

// simple cart
let cart = JSON.parse(localStorage.getItem('gj_cart')||'{}');

function saveCart(){ localStorage.setItem('gj_cart', JSON.stringify(cart)); updateCartUI(); }
function updateCartUI(){
  const items = Object.values(cart);
  let total = 0, qty=0;
  cartItemsDiv.innerHTML='';
  if(items.length===0){
    cartItemsDiv.innerHTML = '<p class="muted">Cart is empty.</p>';
  } else {
    items.forEach(it=>{
      const row = document.createElement('div'); row.style.display='flex';row.style.justifyContent='space-between';row.style.marginTop='.5rem';
      row.innerHTML = `<div>${it.name} × ${it.qty}</div><div>$${(it.price*it.qty).toFixed(2)}</div>`;
      cartItemsDiv.appendChild(row);
      total += it.price*it.qty; qty += it.qty;
    });
  }
  cartCount.textContent = qty;
  cartTotal.textContent = total.toFixed(2);
}

// add handlers
document.addEventListener('click', e=>{
  if(e.target.matches('.add')){
    const id = e.target.dataset.id;
    const p = products.find(x=>x.id===id);
    if(!cart[id]) cart[id] = {id:p.id,name:p.name,price:p.price,qty:0};
    cart[id].qty += 1;
    saveCart();
    // tiny confetti-ish effect: flash
    e.target.textContent = 'Added ✓'; setTimeout(()=>e.target.textContent='Add',900);
  }
});

cartBtn.addEventListener('click', ()=>{ cartModal.setAttribute('aria-hidden','false'); });
closeCart.addEventListener('click', ()=>{ cartModal.setAttribute('aria-hidden','true'); });
checkoutBtn.addEventListener('click', ()=>{
  alert('Demo checkout — connect a payment provider (Stripe, PayPal, etc.) to actually accept payments.');
});

// contact form
$('#contactForm').addEventListener('submit', e=>{
  e.preventDefault();
  const name = $('#name').value.trim();
  const email = $('#email').value.trim();
  const message = $('#message').value.trim();
  $('#contactStatus').textContent = 'Sending...';
  // demo behavior: pretend to send and clear
  setTimeout(()=>{
    $('#contactStatus').textContent = 'Thanks, '+name+' — we got your message (demo).';
    $('#contactForm').reset();
  },700);
});

// initialize UI on load
updateCartUI();
